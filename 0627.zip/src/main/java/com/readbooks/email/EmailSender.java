package com.readbooks.email;

public class EmailSender {

}

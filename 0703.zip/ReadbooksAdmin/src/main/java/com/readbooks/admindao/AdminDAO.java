package com.readbooks.admindao;

import com.readbooks.adminvo.AdminVO;

public interface AdminDAO {
	public int login(AdminVO admin);


}

package com.readbooks.adminservice;

import com.readbooks.adminvo.AdminVO;

public interface AdminService {

	public int login(AdminVO admin);


}

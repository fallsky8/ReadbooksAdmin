package com.readbooks.agreementvo;


public class AgreementVO {
	
	private String agreement_serviceagreement;
	private String agreement_collectiveagreement;
	private String agreement_referralagreement;
	
	public AgreementVO() {
		super();
	}

	public String getAgreement_serviceagreement() {
		return agreement_serviceagreement;
	}

	public void setAgreement_serviceagreement(String agreement_serviceagreement) {
		this.agreement_serviceagreement = agreement_serviceagreement;
	}

	public String getAgreement_collectiveagreement() {
		return agreement_collectiveagreement;
	}

	public void setAgreement_collectiveagreement(String agreement_collectiveagreement) {
		this.agreement_collectiveagreement = agreement_collectiveagreement;
	}

	public String getAgreement_referralagreement() {
		return agreement_referralagreement;
	}

	public void setAgreement_referralagreement(String agreement_referralagreement) {
		this.agreement_referralagreement = agreement_referralagreement;
	}


}
